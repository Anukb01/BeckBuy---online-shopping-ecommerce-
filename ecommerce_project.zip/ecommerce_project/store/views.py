

# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404
from .models import Product, CartItem, OrderItem
from django.contrib.auth.decorators import login_required
from .models import Order
from django.shortcuts import get_object_or_404, redirect
from .models import Product
from .models import Category


# 🏠 Home - Show all products
def home(request):
    categories = Category.objects.all()
    products = Product.objects.all()
    return render(request, 'home.html', {
        'products': products,
        'categories': categories
    })

# 🧾 Product Detail
def product_detail(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    return render(request, 'product_detail.html', {'product': product})

# ➕ Add to cart
@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    cart_item, created = CartItem.objects.get_or_create(
        user=request.user,
        product=product,
    )
    if not created:
        cart_item.quantity += 1
    cart_item.save()
    return redirect('home')

# 🛒 View Cart
@login_required
def view_cart(request):
    cart_items = CartItem.objects.filter(user=request.user)
    total = sum(item.product.price * item.quantity for item in cart_items)
    return render(request, 'cart.html', {'cart_items': cart_items, 'total': total})


@login_required
def checkout(request):
    cart_items = CartItem.objects.filter(user=request.user)

    if not cart_items.exists():
        return render(request, 'empty_cart.html')

    if request.method == 'POST':
        phone = request.POST.get('phone')
        address = request.POST.get('address')
        payment_method = request.POST.get('payment_method')

        order = Order.objects.create(user=request.user, phone=phone, address=address)
        total = 0
        order_items = []

        for item in cart_items:
            order_item = OrderItem.objects.create(order=order, product=item.product, quantity=item.quantity)
            subtotal = item.product.price * item.quantity
            total += subtotal
            order_item.subtotal = subtotal  # 👈 manually add for display use
            order_items.append(order_item)

        order.total_price = total
        order.save()
        cart_items.delete()
        
        print("Checkout POST executed")
        
        return render(request, 'order_success.html', {
            'order': order,
            
            'order_items': order_items  # 👈 Pass to template
        })

    return render(request, 'checkout.html')




def update_cart(request, product_id):
    if request.method == 'POST':
        quantity = int(request.POST.get('quantity', 1))
        cart_item = get_object_or_404(CartItem, product__id=product_id, user=request.user)

        if quantity > 0:
            cart_item.quantity = quantity
            cart_item.save()
        else:
            cart_item.delete()

        return redirect('view_cart')
    
def remove_from_cart(request, item_id):  # ← Accept item_id here!
    if request.method == 'POST':
        item = get_object_or_404(CartItem, id=item_id)
        item.delete()
    return redirect('view_cart')
 
def search_products(request):
    query = request.GET.get('q')
    results = []
    if query:
        results = Product.objects.filter(name__icontains=query)
    return render(request, 'search_results.html', {'products': results, 'query': query})

def order_success(request):
    
    return render(request, 'order_success.html'),

def products_by_category(request, category_id):
    category = get_object_or_404(Category, id=category_id)
    products = Product.objects.filter(category=category)
    categories = Category.objects.all()
    return render(request, 'home.html', {
        'products': products,
        'categories': categories,
        'selected_category': category
    })
