from django.contrib import admin
from .models import Category, Product, Order, CartItem, OrderItem

# class OrderItemInline(admin.TabularInline):
#     model = OrderItem
#     extra = 0
#     readonly_fields = ['product', 'quantity']

# class OrderAdmin(admin.ModelAdmin):
#     list_display = ['id', 'user', 'phone', 'address', 'total_price', 'created_at']
#     inlines = [OrderItemInline]  # This shows OrderItem inline



admin.site.register(Product)
admin.site.register(CartItem)
# admin.site.register(Order, OrderAdmin)

admin.site.register(Category)



class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0

class OrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'total_price', 'created_at']
    list_filter = ['created_at', 'user']
    search_fields = ['user__username', 'id']
    inlines = [OrderItemInline]

admin.site.register(Order, OrderAdmin)